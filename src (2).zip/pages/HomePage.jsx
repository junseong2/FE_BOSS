// interface HomePageProps { }

export default function HomePage() {
  return (
    <div>
      홈페<br></br>
      <br></br>
      <br></br>
      <br></br>이지
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br> <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      입니다.
    </div>
  );
}
