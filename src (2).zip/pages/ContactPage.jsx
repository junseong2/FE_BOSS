// src/ContactPage.js
function ContactPage() {
  return <div>연락처 페이지</div>;
}

export default ContactPage;
