import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const pages = ["/", "/about", "/contact","/kakaomap"]; // 새로운 페이지 추가

const ScrollNavigation = () => {
  const navigate = useNavigate();

  useEffect(() => {
    // IntersectionObserver 콜백 함수
    const handleIntersection = (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const index = entry.target.getAttribute("data-page-index");
          navigate(pages[index]); // 해당 페이지로 이동
        }
      });
    };

    // IntersectionObserver 설정
    const observer = new IntersectionObserver(handleIntersection, {
      threshold: 0.5, // 화면의 50% 이상이 보이면 트리거
    });

    // 페이지 내 섹션들을 관찰하도록 설정
    const sections = document.querySelectorAll(".section");
    sections.forEach((section) => {
      observer.observe(section);
    });

    // 정리 함수: 컴포넌트 언마운트 시 옵저버 해제
    return () => {
      observer.disconnect();
    };
  }, [navigate]);

  return (
    <div>
      <div className="section" data-page-index="0">
        <h1>Page 1</h1>
        <p>This is the first page.</p>
      </div>
      <div className="section" data-page-index="1">
        <h1>Page 2</h1>
        <p>This is the second page.</p>
      </div>
    </div>
  );
};

export default ScrollNavigation;
