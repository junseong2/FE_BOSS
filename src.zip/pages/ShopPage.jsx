import { useParams } from 'react-router-dom';
import Top from '../components/layout/Top';
import Top5 from '../components/layout/Top5';
import MenuBar from '../MenuBar';
import MenuBar5 from '../MenuBar5';
import MenuBarNull from '../MenuBarNull';
import ScrollNavigation from '../components/ScrollNavigation';
import SwipeNavigation from '../components/SwipeNavigation';
import TopbarNavigation from '../components/TopbarNavigation';
import { useState, useEffect } from 'react';

function ShopPage({ sellerId }) {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    if (!sellerId) return;

    const fetchProducts = async () => {
      try {
        const response = await fetch(`http://localhost:5000/products/seller/${sellerId}`);
        if (!response.ok) {
          throw new Error(`API 오류: ${response.status}`);
        }

        const data = await response.json();
        setProducts(data);
      } catch (error) {
        console.error("상품 목록을 불러오는 중 오류 발생:", error);
      }
    };

    fetchProducts();
  }, [sellerId]);

  return (
    <div>
      <h1>상품 목록</h1>
      <ul>
        {products.length > 0 ? (
          products.map((product) => (
            <li key={product.product_id}>
              <img src={product.image_url} alt={product.name} width="100" />
              <h3>{product.name}</h3>
              <p>{product.description}</p>
              <p>가격: {product.price}원</p>
              <p>유통기한: {product.expiry_date}</p>
            </li>
          ))
        ) : (
          <p>상품이 없습니다.</p>
        )}
      </ul>
    </div>
  );
}

export default ShopPage;
