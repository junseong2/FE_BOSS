// src/ContactPage.js
function EventPage() {
  return <div>이벤트 페이지</div>;
}

export default EventPage;
