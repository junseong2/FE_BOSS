export default function SellerContentHeader({ children }) {
  return <div aria-label='seller contents header'>{children}</div>;
}
