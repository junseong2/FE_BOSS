import SellerTitle from './components/SellerTitle';

function SellerPaymentPage() {
  return (
    <div>
      <SellerTitle type={'main'}>정산 관리</SellerTitle>
    </div>
  );
}

export default SellerPaymentPage;
