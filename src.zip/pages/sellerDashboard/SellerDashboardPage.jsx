import SellerTitle from './components/SellerTitle';

function SellerDashboardPage() {
  return (
    <div>
      <SellerTitle type={'main'}>대시보드</SellerTitle>
    </div>
  );
}

export default SellerDashboardPage;
