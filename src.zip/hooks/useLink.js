export default function useLink() {}
