import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { CartProvider } from './context/CartContext';
import AppLayout from './AppLayout';  // ✅ AppLayout import 추가
import ShopPage from './pages/ShopPage';

import './App.css';
import './layout.css';
import Top from './components/layout/Top';
import MenuBar from './MenuBar';



import SignIn from './pages/SignIn.jsx';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import CartPage from './pages/CartPage';
import CameraCapturePage from './pages/CameraCapturePage';
import ContactPage from './pages/ContactPage';
import MyPage from './pages/MyPage';
import EventPage from './pages/EventPage';
import KakaoMapPage from './pages/KakaoMapPage';
import SignUp from './pages/SignUp';
import CategoryPage from './pages/CategoryPage';
import SearchPage from './pages/SearchPage';

import SellerPage from './pages/sellerDashboard/SellerPage.jsx';
import SellerDashboardPage from './pages/sellerDashboard/SellerDashboardPage.jsx';
import SellerProductPage from './pages/sellerDashboard/SellerProductPage.jsx';
import SellerOrderPage from './pages/sellerDashboard/SellerOrderPage.jsx';
import SellerInventoryPage from './pages/sellerDashboard/SellerInventoryPage.jsx';
import SellerSalesPage from './pages/sellerDashboard/SellerSalesPage.jsx';
import SellerPaymentPage from './pages/sellerDashboard/SellerPaymentPage.jsx';
import ProductDetailPage from './pages/ProductDetailPage';

function App() {
  const [storename, setStorename] = useState(null);
  const [headerId, setHeaderId] = useState(null);
  const [sellerId, setSellerId] = useState(null);
  const [menuBarId, setMenuBarId] = useState(null);
  const [navigationId, setNavigationId] = useState(null);
  const [loading, setLoading] = useState(true);

  const location = useLocation();
  const isAdminPage = location.pathname.toLowerCase().startsWith('/seller') ||
                      location.pathname.toLowerCase().startsWith('/admin');

  useEffect(() => {
    if (!storename) {
      setLoading(false);
      return;
    }

    const fetchSellerInfo = async () => {
      try {
        const sellerResponse = await fetch(`http://localhost:5000/seller/info/${storename}`, {
          method: 'GET',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
        });

        if (!sellerResponse.ok) {
          throw new Error(`API 오류 상태: ${sellerResponse.status}`);
        }

        const sellerData = await sellerResponse.json();
        setHeaderId(sellerData.headerId ?? null);
        setMenuBarId(sellerData.menuBarId ?? null);
        setSellerId(sellerData.Id ?? null);
        setNavigationId(sellerData.navigationId ?? null);

        console.log("seller:"+sellerData);
      } catch (error) {
        console.error("API 호출 실패:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchSellerInfo();
  }, [storename]);

  return (
    
    <CartProvider>
      
          {/* ✅ 관리자 페이지가 아닐 때만 `Top`과 `MenuBar` 렌더링 */}
          {!isAdminPage && <Top />}
          {!isAdminPage && <MenuBar />}
          
          <div className="flex">
            {loading ? (
              <div className="loading-screen">
                <h2>🔄 데이터 불러오는 중...</h2>
              </div>
            ) : (
            <Routes>
              <Route path="/:storename/*" element={<AppLayout sellerId= {sellerId} headerId={headerId} menuBarId={menuBarId} navigationId={navigationId} setStorename={setStorename} />}>
                <Route path="shop" element={<ShopPage headerId={headerId} menuBarId={menuBarId} navigationId={navigationId} />} />
              </Route>

              {/* ✅ 일반적인 페이지 경로 유지 */}
              <Route path="/" element={<HomePage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/event" element={<EventPage />} />
              <Route path="/kakaomap" element={<KakaoMapPage />} />
              <Route path="/camera" element={<CameraCapturePage />} />
              <Route path="/signin" element={<SignIn />} />
              <Route path="/mypage" element={<MyPage />} />
              <Route path="/signup" element={<SignUp />} />
              <Route path="/cart" element={<CartPage />} />
              <Route path="/category/:categoryId" element={<CategoryPage />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/product/:productId" element={<ProductDetailPage />} />

              {/* ✅ 판매자 대시보드 경로 유지 */}
              <Route path="/seller" element={<SellerPage />}>
                <Route index path="dashboard" element={<SellerDashboardPage />} />
                <Route path="product" element={<SellerProductPage />} />
                <Route path="order" element={<SellerOrderPage />} />
                <Route path="inventory" element={<SellerInventoryPage />} />
                <Route path="sales" element={<SellerSalesPage />} />
                <Route path="payment" element={<SellerPaymentPage />} />
              </Route>
            </Routes>
          )}
        </div>
    </CartProvider>
  );
}

export default App;
